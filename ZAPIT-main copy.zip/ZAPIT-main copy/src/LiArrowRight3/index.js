export { LiArrowRight3 } from "./LiArrowRight3";
