import React from "react";

import { LiArrowRight4 } from "../LiArrowRight4";
import { LiSearch } from "../LiSearch";

export const Home = () => {
  return (  <>
    <div className="absolute w-[1442px] h-[101px] top-0 -left-0.5">
      <div className="inline-flex flex-col items-start absolute top-0 left-0.5">
        <div className="relative w-[1440px] h-10 bg-[#eeeeee]" />

        <div className="relative w-[1440px] h-[49px] bg-white shadow-[0px_2px_2px_#0000001a]">
          <div className="inline-flex h-10 items-center justify-center gap-[100px] relative top-2 left-[772px]">
            <div className="inline-flex items-center justify-center gap-6 relative flex-[0_0_auto]">
              <div className="inline-flex items-start gap-[5px] p-2.5 relative flex-[0_0_auto]">
                <button>
                <div className="font-bold text-base relative w-fit mt-[-1.00px] [font-family:'Quicksand',Helvetica] text-black tracking-[0] leading-[normal]">
                  Home
                </div>
                  </button>
              </div>
             <button>
              <div className="inline-flex items-start gap-[5px] p-2.5 relative flex-[0_0_auto]">
                <div className="mt-[-1.00px] font-medium relative w-fit [font-family:'Quicksand',Helvetica] text-black text-base tracking-[0] leading-[normal]">
                  Shop
                </div>
              </div>
               </button>
              <button>
              <div className="inline-flex items-start gap-[5px] p-2.5 relative flex-[0_0_auto]">
                <div className="relative w-fit mt-[-1.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-base tracking-[0] leading-[normal]">
                  Orders
                </div>
              </div>
             </button>
              <button>
              <div className="inline-flex items-start gap-[5px] p-2.5 relative flex-[0_0_auto]">
                <div className="relative w-fit mt-[-1.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-base tracking-[0] leading-[normal]">
                  My Profile
                </div>
              </div>
                </button>
            </div>
           
            <div className="inline-flex items-center justify-center gap-[30px] relative flex-[0_0_auto]">
                  <button>
              <div className="inline-flex items-center justify-center gap-2.5 relative flex-[0_0_auto]">
            
                <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-base tracking-[0] leading-[normal]">
                  Cart
                </div>
              
                
                <img
                  className="relative w-[30px] h-[30px]"
                  alt="Cart icon span"
                  src="https://c.animaapp.com/VInChtkF/img/cart-icon-span-2.svg"
                />
      
              </div>
                 </button>
              <button>
              <div className="inline-flex items-center justify-center gap-2.5 relative flex-[0_0_auto]">
                <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-base tracking-[0] leading-[normal]">
                  Login
                </div>

                <img
                  className="relative w-[30px] h-[30px]"
                  alt="Cart icon span"
                  src="https://c.animaapp.com/VInChtkF/img/cart-icon-span-3.svg"
                />
              </div>
                </button>
            </div>
              
          </div>
        </div>

        <div className="flex w-[529px] h-[37px] items-start justify-between absolute top-[47px] left-[90px] bg-[#c5ead9c7] rounded-[5px] overflow-hidden shadow-[0px_4px_4px_#00000040]">
          <button>
          <div className="flex w-[60px] items-center justify-center gap-[9px] p-[21px] relative self-stretch bg-white rounded-[0px_2px_2px_0px]">
            <LiSearch className="!relative !w-6 !h-6 !mt-[-14.50px] !mb-[-14.50px] !ml-[-3.00px] !mr-[-3.00px]" />
          </div>
            </button>
          

          <div className="flex w-[468px] items-center relative self-stretch bg-white">
            <div className="flex w-[166.96px] items-center justify-center gap-3 relative">
              <img
                className="relative w-px h-[13.5px]"
                alt="Vector"
                src="https://c.animaapp.com/VInChtkF/img/vector-1-1.svg"
              />

              <div className="relative w-fit mt-[-1.00px] [font-family:'Quicksand',Helvetica] font-medium text-[#00000080] text-sm tracking-[0] leading-[normal]">
                Search for items...
              </div>
            </div>
          </div>
        </div>
      </div>
      <button>
      <div className="absolute w-[55px] h-[70px] top-[31px] left-0">
        <div className="relative w-[51px] h-[70px] left-0.5">
          <div className="absolute w-[37px] top-[41px] left-1.5 [font-family:'Inter',Helvetica] font-semibold text-black text-xs text-center tracking-[0] leading-[normal]">
            ZapIt
          </div>

          <img
            className="absolute w-[51px] h-[70px] top-0 left-0 object-cover"
            alt="Screenshot"
            src="https://c.animaapp.com/VInChtkF/img/screenshot-2024-12-08-at-11-27-49-am-1-10@2x.png"
          />
        </div>
      </div>
        </button>
    </div>
      

    <div className="absolute w-[1400px] h-[500px] top-[140px] left-5 bg-[url(https://c.animaapp.com/VInChtkF/img/hero-bg-1.png)] bg-cover bg-[50%_50%]">
      <div className="flex flex-col w-[830px] items-start justify-center gap-5 absolute top-[93px] left-[30px] rounded-[15px]">
        <p className="relative self-stretch mt-[-1.00px] [font-family:'Quicksand',Helvetica] font-bold text-white text-[50px] tracking-[-0.50px] leading-[normal]">
          Fresh Savings Every Week! Enjoy Up to 30% Off on Select Produce.
        </p>

        <p className="relative self-stretch [font-family:'Quicksand',Helvetica] font-bold text-[#f6e2ab] text-xl tracking-[-0.20px] leading-[normal]">
          Fresh fruits and vegetables, packaged goods, snacks, beverages,
          household essentials.
        </p>

        <button className="all-[unset] box-border bg-white flex w-[143px] h-[52px] items-center justify-center gap-[9px] p-3.5 relative rounded-[5px] overflow-hidden">
          <div className="font-bold relative w-fit [font-family:'Quicksand',Helvetica] text-black text-base tracking-[0] leading-[normal]">
            Shop Now
          </div>
        </button>
      </div>

      <img
        className="absolute w-[479px] h-[453px] top-6 left-[921px]"
        alt="Hero image"
        src="https://c.animaapp.com/VInChtkF/img/hero-image-1@2x.png"
      />
    </div>

    <div className="absolute w-[1440px] h-[2082px] top-[640px] left-0">
      <div className="inline-flex flex-col items-start gap-[30px] px-0 py-[30px] absolute top-0 left-0">
        <div className="flex flex-col w-[1440px] items-center justify-center gap-5 px-[70px] py-0 relative flex-[0_0_auto]">
          <div className="w-[1300px] relative flex-[0_0_auto]" />
       
          <div className="flex w-[1300px] items-center justify-between relative flex-[0_0_auto]">
            <button>
            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-92@2x.png"
              />

              <div className="relative w-fit ml-[-5.50px] mr-[-5.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Fresh Produce
              </div>
              
              
            </div>
        </button>
            <button>
            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-93@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Herbs &amp; Spices
              </div>
            </div>
           </button>
            <button>
            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-94@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Dairy &amp; Eggs
              </div>
            </div>
          </button>
             <button>
            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-41-13@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Meat &amp; Poultry
              </div>
            </div>
          </button>
          <button>
            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-95@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Beverages
              </div>
            </div>
             </button>
          <button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-96@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Bakery
              </div>
            </div>
             </button>
          <button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-97@2x.png"
              />

              <div className="relative w-fit ml-[-2.00px] mr-[-2.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Frozen Foods
              </div>
            </div>
             </button>
          <button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-98@2x.png"
              />

              <div className="relative w-fit ml-[-7.50px] mr-[-7.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Canned Goods
              </div>
            </div>
          </button>
          </div>
          
           

          <div className="flex w-[1300px] items-center justify-between relative flex-[0_0_auto]">
            <button>
            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-92@2x.png"
              />

              <div className="relative w-fit ml-[-5.50px] mr-[-5.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Fresh Produce
              </div>
                  
            </div>
            

              </button>
            <button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-93@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Herbs &amp; Spices
              </div>
            </div>
              </button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-94@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Dairy &amp; Eggs
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-41-13@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Meat &amp; Poultry
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-95@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Beverages
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-96@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Bakery
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-97@2x.png"
              />

              <div className="relative w-fit ml-[-2.00px] mr-[-2.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Frozen Foods
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-98@2x.png"
              />

              <div className="relative w-fit ml-[-7.50px] mr-[-7.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Canned Goods
              </div>
            </div></button>
          </div>

          <div className="flex w-[1300px] items-center justify-between relative flex-[0_0_auto]">
            <button><div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-92@2x.png"
              />

              <div className="relative w-fit ml-[-5.50px] mr-[-5.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Fresh Produce
              </div>
            </div>
              </button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-93@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Herbs &amp; Spices
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-94@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Dairy &amp; Eggs
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-41-13@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Meat &amp; Poultry
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-95@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Beverages
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-96@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Bakery
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-97@2x.png"
              />

              <div className="relative w-fit ml-[-2.00px] mr-[-2.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Frozen Foods
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-98@2x.png"
              />

              <div className="relative w-fit ml-[-7.50px] mr-[-7.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Canned Goods
              </div>
            </div></button>
          </div>

          <div className="flex w-[1300px] items-center justify-between relative flex-[0_0_auto]">
           <button>
            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-92@2x.png"
              />

              <div className="relative w-fit ml-[-5.50px] mr-[-5.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Fresh Produce
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-93@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Herbs &amp; Spices
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-94@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Dairy &amp; Eggs
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-41-13@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Meat &amp; Poultry
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-95@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Beverages
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-96@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Bakery
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-97@2x.png"
              />

              <div className="relative w-fit ml-[-2.00px] mr-[-2.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Frozen Foods
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-98@2x.png"
              />

              <div className="relative w-fit ml-[-7.50px] mr-[-7.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Canned Goods
              </div>
            </div></button>
          </div>

          <div className="flex w-[1300px] items-center justify-between relative flex-[0_0_auto]">
            <button>
            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-92@2x.png"
              />

              <div className="relative w-fit ml-[-5.50px] mr-[-5.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Fresh Produce
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-93@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Herbs &amp; Spices
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-94@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Dairy &amp; Eggs
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-41-13@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Meat &amp; Poultry
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-95@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Beverages
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-96@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Bakery
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-97@2x.png"
              />

              <div className="relative w-fit ml-[-2.00px] mr-[-2.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Frozen Foods
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-98@2x.png"
              />

              <div className="relative w-fit ml-[-7.50px] mr-[-7.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Canned Goods
              </div>
            </div></button>
          </div>

          <div className="flex w-[1300px] items-center justify-between relative flex-[0_0_auto]">
           <button>
            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-92@2x.png"
              />

              <div className="relative w-fit ml-[-5.50px] mr-[-5.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Fresh Produce
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-93@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Herbs &amp; Spices
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-94@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Dairy &amp; Eggs
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-41-13@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Meat &amp; Poultry
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-95@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Beverages
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-96@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Bakery
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-97@2x.png"
              />

              <div className="relative w-fit ml-[-2.00px] mr-[-2.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Frozen Foods
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-98@2x.png"
              />

              <div className="relative w-fit ml-[-7.50px] mr-[-7.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Canned Goods
              </div>
            </div></button>
          </div>

          <div className="flex w-[1300px] items-center justify-between relative flex-[0_0_auto]">
            <button><div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-92@2x.png"
              />

              <div className="relative w-fit ml-[-5.50px] mr-[-5.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Fresh Produce
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-93@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Herbs &amp; Spices
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-94@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Dairy &amp; Eggs
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-41-13@2x.png"
              />

              <div className="relative w-fit ml-[-8.00px] mr-[-8.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Meat &amp; Poultry
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-95@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Beverages
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-96@2x.png"
              />

              <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Bakery
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-97@2x.png"
              />

              <div className="relative w-fit ml-[-2.00px] mr-[-2.00px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Frozen Foods
              </div>
            </div></button><button>

            <div className="flex flex-col w-[150px] h-[180px] items-center justify-end gap-[25px] p-5 relative bg-[#f6e2ab66] rounded-[5px]">
              <img
                className="relative flex-1 self-stretch w-full grow"
                alt="Image"
                src="https://c.animaapp.com/VInChtkF/img/image-98@2x.png"
              />

              <div className="relative w-fit ml-[-7.50px] mr-[-7.50px] [font-family:'Quicksand',Helvetica] font-medium text-black text-lg tracking-[0] leading-[normal]">
                Canned Goods
              </div>
            </div></button>
          </div>
        </div>

        <div className="absolute top-[18px] left-[69px] [font-family:'Quicksand',Helvetica] font-bold text-black text-[25px] tracking-[0] leading-[normal]">
          Explore Categories
        </div>
      </div>

      <div className="flex w-[1440px] h-[640px] items-start gap-5 px-[30px] py-[50px] absolute top-[1442px] left-0">
        <div className="flex flex-col items-start gap-10 px-[30px] py-[50px] relative flex-1 self-stretch grow bg-[#c5ead9c7] rounded-[10px] overflow-hidden shadow-[0px_4px_4px_#00000040]">
          <p className="relative self-stretch mt-[-1.00px] [font-family:'Quicksand',Helvetica] font-bold text-black text-[40px] tracking-[-0.40px] leading-[normal]">
            Get Your Groceries Delivered for Free
          </p>

          <p className="relative self-stretch [font-family:'Quicksand',Helvetica] font-normal text-black text-[17px] tracking-[-0.17px] leading-[normal]">
            Order now and get free delivery on orders above 50,000 NGN.
            Shop from the comfort of your home and let us bring your
            groceries to you.
          </p>

          <div className="bg-[#263238] flex w-[143px] h-[52px] items-center justify-center gap-[9px] p-3.5 relative rounded-[5px] overflow-hidden">
            <button>
            <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-bold text-white text-base tracking-[0] leading-[normal]">
              Order Now
            </div>
              </button>

            <LiArrowRight4
              className="!relative !w-[18px] !h-[18px]"
              color="white"
            />
          </div>

          <img
            className="absolute w-[254px] h-[269px] top-[258px] left-[186px]"
            alt="Biker"
            src="https://c.animaapp.com/VInChtkF/img/biker-1@2x.png"
          />
        </div>

        <div className="flex flex-col items-center justify-between px-[30px] py-[25px] relative flex-1 self-stretch grow bg-[#dfb33d] rounded-[10px] shadow-[0px_4px_4px_#00000040]">
          <div className="flex flex-col items-center gap-2.5 self-stretch w-full relative flex-[0_0_auto]">
            <div className="inline-flex items-center gap-2.5 px-[30px] py-2.5 bg-[#263238] rounded-[10px] relative flex-[0_0_auto]">
              <div className="relative w-fit mt-[-1.00px] [font-family:'Poppins',Helvetica] font-bold text-white text-xl text-center tracking-[0] leading-[23px] whitespace-nowrap">
                BEST DEALS
              </div>
            </div>

            <div className="relative self-stretch [font-family:'Poppins',Helvetica] font-bold text-white text-[40px] text-center tracking-[0] leading-[48px]">
              Deals of the Day
            </div>

            <div className="flex w-[284px] items-center justify-between relative flex-[0_0_auto]">
              <div className="inline-flex flex-col items-start gap-2 relative flex-[0_0_auto]">
                <div className="relative w-[54px] mt-[-1.00px] [font-family:'Poppins',Helvetica] font-black text-white text-[28px] text-center tracking-[0] leading-[35px]">
                  00
                </div>

                <div className="relative w-[54px] [font-family:'Quicksand',Helvetica] font-normal text-white text-[15px] text-center tracking-[0] leading-[23px]">
                  DAYS
                </div>
              </div>

              <div className="relative w-5 [font-family:'Quicksand',Helvetica] font-normal text-white text-base text-center tracking-[0] leading-[23px]">
                :
              </div>

              <div className="inline-flex flex-col items-start gap-2 relative flex-[0_0_auto]">
                <div className="relative w-[54px] mt-[-1.00px] [font-family:'Poppins',Helvetica] font-black text-white text-[28px] text-center tracking-[0] leading-[35px]">
                  02
                </div>

                <div className="relative w-[54px] [font-family:'Quicksand',Helvetica] font-normal text-white text-[15px] text-center tracking-[0] leading-[23px]">
                  HOURS
                </div>
              </div>

              <div className="relative w-5 [font-family:'Quicksand',Helvetica] font-normal text-white text-base text-center tracking-[0] leading-[23px]">
                :
              </div>

              <div className="inline-flex flex-col items-start gap-2 relative flex-[0_0_auto]">
                <div className="relative w-[54px] mt-[-1.00px] [font-family:'Poppins',Helvetica] font-black text-white text-[28px] text-center tracking-[0] leading-[35px]">
                  28
                </div>

                <div className="relative w-[54px] [font-family:'Quicksand',Helvetica] font-normal text-white text-[15px] text-center tracking-[0] leading-[23px]">
                  MINS
                </div>
              </div>

              <div className="relative w-5 [font-family:'Quicksand',Helvetica] font-normal text-white text-base text-center tracking-[0] leading-[23px]">
                :
              </div>

              <div className="inline-flex flex-col items-start gap-2 relative flex-[0_0_auto]">
                <div className="relative w-[54px] mt-[-1.00px] [font-family:'Poppins',Helvetica] font-black text-white text-[28px] text-center tracking-[0] leading-[35px]">
                  26
                </div>

                <div className="relative w-[54px] [font-family:'Quicksand',Helvetica] font-normal text-white text-[15px] text-center tracking-[0] leading-[23px]">
                  SECS
                </div>
              </div>
            </div>
          </div>

          <button className="all-[unset] box-border px-[30px] py-5 bg-white rounded-[100px] inline-flex items-center justify-center relative flex-[0_0_auto] overflow-hidden">
            <div className="[font-family:'Poppins',Helvetica] font-bold relative w-fit mt-[-1.00px] text-[#161b1f] text-2xl text-center tracking-[0] leading-6 whitespace-nowrap">
              Shop Now
            </div>
          </button>

          <img
            className="absolute w-[218px] h-[223px] top-[215px] left-[114px]"
            alt="Element"
            src="https://c.animaapp.com/VInChtkF/img/11059441-47048-removebg-preview-1-1@2x.png"
          />
        </div>

        <div className="flex flex-col items-start gap-5 p-[30px] relative flex-1 self-stretch grow bg-[#ed847e] rounded-[10px] overflow-hidden shadow-[0px_4px_4px_#00000040]">
          <img
            className="absolute w-[447px] h-[436px] top-[104px] left-0"
            alt="Element removebg"
            src="https://c.animaapp.com/VInChtkF/img/2148610582-removebg-preview-1-1@2x.png"
          />

          <div className="flex flex-col items-start gap-[5px] self-stretch w-full relative flex-[0_0_auto]">
            <div className="relative self-stretch mt-[-1.00px] [font-family:'Urbanist',Helvetica] font-black text-white text-[40px] tracking-[0] leading-[48px]">
              Weekend Deals
            </div>

            <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-bold text-[#253d4e] text-[35px] tracking-[0] leading-[normal]">
              10% OFF
            </div>
          </div>

          <button className="all-[unset] box-border px-[30px] py-5 bg-white rounded-[100px] inline-flex items-center justify-center relative flex-[0_0_auto] overflow-hidden">
            <div className="font-button font-[number:var(--button-font-weight)] relative w-fit mt-[-1.00px] text-[#161b1f] text-[length:var(--button-font-size)] text-center tracking-[var(--button-letter-spacing)] leading-[var(--button-line-height)] whitespace-nowrap [font-style:var(--button-font-style)]">
              Shop Now
            </div>
          </button>
        </div>
      </div>
    </div>

    <footer className="flex w-[1440px] items-start gap-[100px] p-20 absolute top-[2722px] left-0 bg-[#f6e2ab66]">
      <div className="absolute w-64 h-[261px] top-[22px] left-3.5">
        <div className="relative w-[254px] h-[261px]">
          <div className="absolute w-[177px] top-[151px] left-[47px] [font-family:'Inter',Helvetica] font-semibold text-black text-4xl text-center tracking-[0] leading-[normal]">
            ZapIt
          </div>

          <img
            className="absolute w-[254px] h-[261px] top-0 left-0 object-cover"
            alt="Screenshot"
            src="https://c.animaapp.com/VInChtkF/img/screenshot-2024-12-08-at-11-27-49-am-1-11@2x.png"
          />
        </div>
      </div>

      <div className="flex flex-col w-[550px] items-start gap-2.5 pt-[165px] pb-0 px-0 relative">
        <div className="flex flex-col items-start justify-center gap-2.5 relative self-stretch w-full flex-[0_0_auto]">
          <div className="relative self-stretch mt-[-1.00px] [font-family:'Urbanist',Helvetica] font-normal text-black text-[25px] tracking-[0] leading-[normal]">
            Subscribe to our Newsletter
          </div>

          <div className="flex items-center justify-between pl-5 pr-2.5 py-2.5 relative self-stretch w-full flex-[0_0_auto] bg-white rounded-[15px] overflow-hidden">
            <div className="relative w-fit opacity-50 [font-family:'Quicksand',Helvetica] font-medium text-[#253d4e] text-xl tracking-[0] leading-[normal]">
              Enter your email
            </div>

            <button className="all-[unset] box-border px-5 py-[15px] bg-black rounded-[10px] inline-flex items-center justify-center relative flex-[0_0_auto] overflow-hidden">
              <div className="relative w-[120px] mt-[-1.00px] font-button font-[number:var(--button-font-weight)] text-white text-[length:var(--button-font-size)] text-center tracking-[var(--button-letter-spacing)] leading-[var(--button-line-height)] [font-style:var(--button-font-style)]">
                Subscribe
              </div>
            </button>
          </div>
        </div>
      </div>

      <div className="flex items-start justify-between relative flex-1 grow">
        <div className="flex flex-col items-start justify-between relative flex-1 self-stretch grow">
         <button>
          <div className="font-medium text-xl relative w-fit mt-[-1.00px] [font-family:'Quicksand',Helvetica] text-black tracking-[0] leading-[normal]">
            Home
          </div>
        </button>
          <button>
          <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-xl tracking-[0] leading-[normal]">
            Shop
          </div>
          </button>
          <button>
          <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-xl tracking-[0] leading-[normal]">
            Categories
          </div>
         </button>
          <button>
          <div className="relative w-fit [font-family:'Quicksand',Helvetica] font-medium text-black text-xl tracking-[0] leading-[normal]">
            Contact Us
          </div>
           </button>
        </div>

        <div className="flex flex-col items-start gap-[50px] relative flex-1 self-stretch grow">
          <div className="inline-flex flex-col items-start gap-[60px] relative flex-[0_0_auto]">
            <div className="inline-flex items-center gap-2.5 relative flex-[0_0_auto]">
              <img
                className="relative w-5 h-5"
                alt="Group"
                src="https://c.animaapp.com/VInChtkF/img/group-61-5@2x.png"
              />

              <input
                className="relative w-fit mt-[-1.00px] [font-family:'Urbanist',Helvetica] font-normal text-black text-xl tracking-[0] leading-[23px] whitespace-nowrap [background:transparent] border-[none] p-0"
                placeholder="zapit@website.com"
                type="email"
              />
            </div>

            <div className="inline-flex items-center gap-2.5 relative flex-[0_0_auto]">
              <img
                className="relative w-4 h-[18.31px]"
                alt="Group"
                src="https://c.animaapp.com/VInChtkF/img/group-62-5@2x.png"
              />

              <div className="relative w-fit mt-[-1.00px] [font-family:'Urbanist',Helvetica] font-normal text-black text-xl tracking-[0] leading-[23px] whitespace-nowrap">
                Navi Mumbai, Maharashtra
              </div>
            </div>

            <div className="inline-flex items-center gap-2.5 relative flex-[0_0_auto]">
              <img
                className="relative w-[17.99px] h-[17.98px]"
                alt="Group"
                src="https://c.animaapp.com/VInChtkF/img/group-63-5@2x.png"
              />

              <div className="relative w-fit mt-[-1.00px] [font-family:'Urbanist',Helvetica] font-normal text-black text-xl tracking-[0] leading-[23px] whitespace-nowrap">
                +91 XXXXXXXXXX
              </div>
            </div>
          </div>

          <img
            className="relative self-stretch w-full flex-[0_0_auto]"
            alt="Sosmed"
            src="https://c.animaapp.com/VInChtkF/img/sosmed-5.svg"
          />
        </div>
      </div>
    </footer>
  </>
  );
};

export default Home;