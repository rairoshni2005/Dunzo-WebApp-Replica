
import React from "react";

export const LiSearch = ({ className }) => {
  return (
    <svg
      className={`${className}`}
      fill="none"
      height="25"
      viewBox="0 0 24 25"
      width="24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        clipRule="evenodd"
        d="M11 4.5C7.13401 4.5 4 7.63401 4 11.5C4 15.366 7.13401 18.5 11 18.5C14.866 18.5 18 15.366 18 11.5C18 7.63401 14.866 4.5 11 4.5ZM2 11.5C2 6.52944 6.02944 2.5 11 2.5C15.9706 2.5 20 6.52944 20 11.5C20 16.4706 15.9706 20.5 11 20.5C6.02944 20.5 2 16.4706 2 11.5Z"
        fill="black"
        fillRule="evenodd"
      />

      <path
        clipRule="evenodd"
        d="M15.9433 16.4433C16.3338 16.0528 16.967 16.0528 17.3575 16.4433L21.7075 20.7933C22.098 21.1838 22.098 21.817 21.7075 22.2075C21.317 22.598 20.6838 22.598 20.2933 22.2075L15.9433 17.8575C15.5528 17.467 15.5528 16.8338 15.9433 16.4433Z"
        fill="black"
        fillRule="evenodd"
      />
    </svg>
  );
};
