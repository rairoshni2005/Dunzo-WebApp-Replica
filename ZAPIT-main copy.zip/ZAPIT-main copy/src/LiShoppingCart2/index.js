export { LiShoppingCart2 } from "./LiShoppingCart2";
