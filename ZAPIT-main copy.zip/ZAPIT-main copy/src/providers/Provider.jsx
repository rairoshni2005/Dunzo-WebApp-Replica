import { BrowserRouter, Routes } from "react-router-dom";

const Provider = ({ children }) => {
    return (
        <BrowserRouter>
            <Routes>{children}</Routes>
        </BrowserRouter>
    );
};

export default Provider;
