import { Route } from "react-router-dom";
import Provider from "@providers/Provider";
import Home from "@pages/Home";

const App = () => {
    return (
        <Provider>
            <Route path="/" element={<Home />} />
        </Provider>
    );
};

export default App;
